# Serverless Cleaner (Vercel)

Déployez un endpoint **/api/clean** qui lit un **CSV/JSON** depuis une URL, appelle **OpenAI (Structured Outputs)**
pour normaliser les lignes, et renvoie du **JSON** ou **CSV** propre — sans rien installer en local.

## Déploiement (Vercel)
1. Créez un nouveau repo GitHub, poussez ces fichiers.
2. Sur Vercel, **Import Project** → choisissez le repo.
3. **Environment Variables** :
   - `OPENAI_API_KEY` = votre clé
   - (optionnel) `CATEGORY_MAP_JSON` = JSON de mapping catégories (ex: `{ "vol":"Vol","intrusion":"Intrusion" }`)
4. Deploy.

## Utilisation
- JSON en sortie :  
  `https://<votre-app>.vercel.app/api/clean?src=<URL_ENCODEE_DU_CSV_OU_JSON>`
- CSV en sortie :  
  `https://<votre-app>.vercel.app/api/clean?src=<URL>&format=csv`
- Source protégée par Bearer token :  
  `https://<...>/api/clean?src=<URL>&auth=<TOKEN>`

La webapp carte peut pointer directement sur cet endpoint (format JSON) en **URL de données**.

## Exemple
```
https://votre-app.vercel.app/api/clean?src=https%3A%2F%2Fexemple.com%2Ffaits.csv
```

## Remarques
- Chunking 300 lignes/appel.
- CORS: `*` (pratique pour front).
- Modèle par défaut: `gpt-4o-mini`.
