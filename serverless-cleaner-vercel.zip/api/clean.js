// api/clean.js
import OpenAI from "openai";
import Papa from "papaparse";

export const config = {
  runtime: "nodejs18"
};

const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

function buildSchema() {
  return {
    name: "CleanedRows",
    schema: {
      type: "object",
      properties: {
        rows: {
          type: "array",
          items: {
            type: "object",
            properties: {
              dep: { type: "string" },
              categorie: { type: "string" },
              date_iso: { type: "string" },
              date_fr: { type: "string" },
              ville: { type: "string" }
            },
            required: ["dep","categorie","date_iso","date_fr","ville"],
            additionalProperties: false
          }
        }
      },
      required: ["rows"],
      additionalProperties: false
    },
    strict: true
  };
}

function chunk(arr, size) {
  const out = [];
  for (let i=0; i<arr.length; i+=size) out.push(arr.slice(i, i+size));
  return out;
}

async function fetchSource(src, auth) {
  const headers = {};
  if (auth) headers["Authorization"] = "Bearer " + auth;
  const r = await fetch(src, { headers });
  if (!r.ok) throw new Error(`Source HTTP ${r.status}`);
  const ct = (r.headers.get("content-type") || "").toLowerCase();
  if (ct.includes("application/json") || src.toLowerCase().endsWith(".json")) {
    const j = await r.json();
    return Array.isArray(j) ? j : (Array.isArray(j.data) ? j.data : []);
  } else {
    const text = await r.text();
    const parsed = Papa.parse(text, { header:true, skipEmptyLines:true });
    return parsed.data;
  }
}

export default async function handler(req, res) {
  // CORS
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET,OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");
  if (req.method === "OPTIONS") return res.status(200).end();

  try {
    const { src, auth = "", format = "json" } = req.query;
    if (!process.env.OPENAI_API_KEY) {
      return res.status(500).json({ error: "OPENAI_API_KEY inexistant (set env)." });
    }
    if (!src) return res.status(400).json({ error: "Paramètre 'src' manquant (URL du CSV/JSON)." });

    const rows = await fetchSource(src, auth);
    if (!rows.length) return res.status(400).json({ error: "Aucune ligne lisible depuis src." });

    // Optional: custom category mapping via env (JSON string)
    let categoryMap = {};
    try {
      if (process.env.CATEGORY_MAP_JSON) categoryMap = JSON.parse(process.env.CATEGORY_MAP_JSON);
    } catch {}

    const system = `Tu es un normaliseur de données sûreté pour la France.
Règles:
- dep: renvoyer "2A"/"2B" ou un code à 2 chiffres (zéro-padding). Ex: 1 -> "01".
- categorie: mapper vers un vocabulaire cible fourni dans vocabulaire; si inconnu, renvoyer la valeur nettoyée sans inventer.
- date: accepter ISO, JJ/MM/AAAA ou numéro Excel; renvoyer date_iso (YYYY-MM-DD) + date_fr (JJ/MM/AAAA) ou "" si impossible.
- ville: Title Case, espaces/accents propres (ne pas inventer).
- Si une valeur est absente, mets "" (jamais null).
- Ne renvoie AUCUN texte libre: uniquement le JSON respectant le schéma.`;

    const batches = chunk(rows, 300);
    const cleanedAll = [];

    for (const b of batches) {
      const user = {
        role: "user",
        content: [
          { type: "text", text: "Harmonise ces lignes selon les règles et ce vocabulaire de catégories." },
          { type: "input_text", text: JSON.stringify({ vocabulaire: categoryMap, rows: b }) }
        ]
      };
      const resp = await client.responses.create({
        model: "gpt-4o-mini",
        input: [ { role: "system", content: system }, user ],
        response_format: { type: "json_schema", json_schema: buildSchema() }
      });
      const payload = resp.output?.[0]?.content?.[0]?.text;
      if (!payload) throw new Error("Réponse vide du modèle.");
      const json = JSON.parse(payload);
      cleanedAll.push(...json.rows);
    }

    if (format === "csv") {
      res.setHeader("Content-Type","text/csv; charset=utf-8");
      return res.status(200).send(Papa.unparse(cleanedAll));
    } else {
      res.setHeader("Content-Type","application/json; charset=utf-8");
      return res.status(200).json({ rows: cleanedAll });
    }
  } catch (e) {
    console.error(e);
    return res.status(500).json({ error: e.message || "Erreur serveur" });
  }
}
